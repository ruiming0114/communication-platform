package com.rm.plat;


import com.rm.plat.pojo.TopicCommentReport;
import com.rm.plat.service.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatApplicationTests {

    @Autowired
    TopicCommentReportService topicCommentReportService;

    @Test
    public void contextLoads(){
        System.out.println(topicCommentReportService.queryUndealTopicCommentReportList());
    }

}
