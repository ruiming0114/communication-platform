package com.rm.plat.service;

import com.rm.plat.pojo.VideoScore;

public interface VideoScoreService {
    float getScoreByUserAndVideo(int userid,int videoid);
    float getAvgScoreByVideo(int videoid);

    int addVideoScore(VideoScore videoScore);
    int updateVideoScore(VideoScore videoScore);
    int deleteVideoScore(int userid,int videoid);

    int cntByVideo(int videoid);
}
