package com.rm.plat.service;


import com.rm.plat.mapper.GroupMapper;
import com.rm.plat.pojo.Group;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupServiceImpl implements GroupService{

    @Autowired
    GroupMapper groupMapper;

    @Override
    public Group queryGroupById(int groupid) {
        return groupMapper.queryGroupById(groupid);
    }

    @Override
    public Group queryGroupByName(String groupname) {
        return groupMapper.queryGroupByName(groupname);
    }

    @Override
    public List<Group> queryGroupList() {
        return groupMapper.queryGroupList();
    }

    @Override
    public int addGroup(Group group) {
        groupMapper.addGroup(group);
        return 1;
    }

    @Override
    public int updateGroup(Group group) {
        groupMapper.updateGroup(group);
        return 1;
    }

    @Override
    public int deleteGroup(int groupid) {
        groupMapper.deleteGroup(groupid);
        return 1;
    }

    @Override
    public int cnt() {
        return groupMapper.cnt();
    }
}
