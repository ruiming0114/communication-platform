package com.rm.plat.service;

import com.rm.plat.mapper.GroupMemberMapper;
import com.rm.plat.pojo.Group;
import com.rm.plat.pojo.GroupMember;
import com.rm.plat.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupMemberServiceImpl implements GroupMemberService {

    @Autowired
    GroupMemberMapper groupMemberMapper;

    @Override
    public List<User> queryGroupMemberListByGroup(int groupid) {
        return groupMemberMapper.queryGroupMemberListByGroup(groupid);
    }

    @Override
    public List<Group> queryGroupListByUser(int userid) {
        return groupMemberMapper.queryGroupListByUser(userid);
    }

    @Override
    public int getAuthority(int groupid, int userid) {
        return groupMemberMapper.getAuthority(groupid,userid);
    }

    @Override
    public int addGroupMember(GroupMember groupMember) {
        groupMemberMapper.addGroupMember(groupMember);
        return 1;
    }

    @Override
    public int updateGroupMember(GroupMember groupMember) {
        groupMemberMapper.updateGroupMember(groupMember);
        return 1 ;
    }

    @Override
    public int deleteGroupMember(int groupid, int userid) {
        groupMemberMapper.deleteGroupMember(groupid,userid);
        return 1;
    }

    @Override
    public int cntMember(int groupid) {
        return groupMemberMapper.cntMember(groupid);
    }
}
