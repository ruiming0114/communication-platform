package com.rm.plat.service;

import com.rm.plat.pojo.BookScore;

public interface BookScoreService {

    float getScoreByUserAndBook(int userid,int bookid);
    float getAvgScoreByBook(int bookid);

    int addBookScore(BookScore bookScore);
    int updateBookScore(BookScore bookScore);
    int deleteBookScore(int userid,int bookid);

    int cntByBook(int bookid);
}
