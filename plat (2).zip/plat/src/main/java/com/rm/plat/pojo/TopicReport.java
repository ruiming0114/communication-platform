package com.rm.plat.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TopicReport {

    private int topicreportid;
    private int topicid;
    private int userid;
    private String title;
    private String content;
    private Time addtime;
    private int deal;
    //0未处理 1 通过 2 拒绝


    public int getTopicreportid() {
        return topicreportid;
    }

    public void setTopicreportid(int topicreportid) {
        this.topicreportid = topicreportid;
    }

    public int getTopicid() {
        return topicid;
    }

    public void setTopicid(int topicid) {
        this.topicid = topicid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Time getAddtime() {
        return addtime;
    }

    public void setAddtime(Time addtime) {
        this.addtime = addtime;
    }

    public int getDeal() {
        return deal;
    }

    public void setDeal(int deal) {
        this.deal = deal;
    }
}
