package com.rm.plat.service;

import com.rm.plat.mapper.TopicMapper;
import com.rm.plat.pojo.Topic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicServiceImpl implements TopicService{

    @Autowired
    TopicMapper topicMapper;

    @Override
    public Topic queryTopicById(int topicid) {
        return topicMapper.queryTopicById(topicid);
    }

    @Override
    public Topic queryTopicByTitle(String title) {
        return topicMapper.queryTopicByTitle(title);
    }

    @Override
    public List<Topic> queryTopicByClassify(String classify) {
        return topicMapper.queryTopicByClassify(classify);
    }

    @Override
    public List<Topic> queryTopicByUser(int userid) {
        return topicMapper.queryTopicByUser(userid);
    }

    @Override
    public List<Topic> queryTopicList() {
        return topicMapper.queryTopicList();
    }

    @Override
    public int addTopic(Topic topic) {
        topicMapper.addTopic(topic);
        return 1;
    }

    @Override
    public int updateTopic(Topic topic) {
        topicMapper.updateTopic(topic);
        return 1;
    }

    @Override
    public int deleteTopic(int topicid) {
        deleteTopic(topicid);
        return 1;
    }

    @Override
    public int cnt() {
        return topicMapper.cnt();
    }
}
