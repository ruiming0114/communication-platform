package com.rm.plat.service;

import com.rm.plat.pojo.VideoReviewLiked;

public interface VideoReviewLikedService {
    int getVideoReviewLikedByUserAndReview(int userid,int videoreviewid);
    int getLikeStatus(int videoreviewid);
    int getAgainstStatus(int videoreviewid);

    int addVideoReviewLiked(VideoReviewLiked videoReviewLiked);
    int updateVideoReviewLiked(VideoReviewLiked videoReviewLiked);
    int deleteVideoReviewLiked(int userid,int videoreviewid);

}
