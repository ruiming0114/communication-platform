package com.rm.plat.service;

import com.rm.plat.mapper.BookMapper;
import com.rm.plat.pojo.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    BookMapper bookMapper;

    @Override
    public Book queryBookByName(String name) {
        return bookMapper.queryBookByName(name);
    }

    @Override
    public List<Book> queryBookList() {
        return bookMapper.queryBookList();
    }

    @Override
    public Book queryBookByID(int bookid) {
        return bookMapper.queryBookByID(bookid);
    }

    @Override
    public int addBook(Book book) {
        bookMapper.addBook(book);
        return 1;
    }

    @Override
    public int updateBook(Book book) {
        bookMapper.updateBook(book);
        return 1;
    }

    @Override
    public int deleteBook(int bookid) {
        bookMapper.deleteBook(bookid);
        return 1;
    }

    @Override
    public int cnt() {
        return bookMapper.cnt();
    }
}
