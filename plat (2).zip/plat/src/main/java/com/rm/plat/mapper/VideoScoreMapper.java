package com.rm.plat.mapper;


import com.rm.plat.pojo.VideoScore;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface VideoScoreMapper {
    float getScoreByUserAndVideo(int userid,int videoid);
    float getAvgScoreByVideo(int videoid);

    int addVideoScore(VideoScore videoScore);
    int updateVideoScore(VideoScore videoScore);
    int deleteVideoScore(int userid,int videoid);

    int cntByVideo(int videoid);
}
