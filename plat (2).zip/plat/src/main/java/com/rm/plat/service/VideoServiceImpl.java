package com.rm.plat.service;

import com.rm.plat.mapper.VideoMapper;
import com.rm.plat.pojo.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideoServiceImpl implements VideoService {

    @Autowired
    VideoMapper videoMapper;

    @Override
    public Video queryVideoByName(String name) {
        return videoMapper.queryVideoByName(name);
    }

    @Override
    public List<Video> queryVideoList() {
        return videoMapper.queryVideoList();
    }

    @Override
    public Video queryVideoByID(int videoid) {
        return videoMapper.queryVideoByID(videoid);
    }

    @Override
    public int addVideo(Video video) {
        videoMapper.addVideo(video);
        return 1;
    }

    @Override
    public int updateVideo(Video video) {
        videoMapper.updateVideo(video);
        return 1;
    }

    @Override
    public int deleteVideo(int videoid) {
        videoMapper.deleteVideo(videoid);
        return 1;
    }

    @Override
    public int cnt() {
        return videoMapper.cnt();
    }
}
