package com.rm.plat.service;

import com.rm.plat.mapper.BookReviewMapper;
import com.rm.plat.pojo.BookReview;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookReviewServiceImpl implements BookReviewService {
    @Autowired
    BookReviewMapper bookReviewMapper;

    @Override
    public BookReview queryBookReviewById(int bookreviewid) {
        return bookReviewMapper.queryBookReviewById(bookreviewid);
    }

    @Override
    public List<BookReview> queryBookReviewListByBookId(int bookid) {
        return bookReviewMapper.queryBookReviewListByBookId(bookid);
    }

    @Override
    public List<BookReview> queryBookReviewListByUserId(int userid) {
        return bookReviewMapper.queryBookReviewListByUserId(userid);
    }

    @Override
    public int addBookReview(BookReview bookReview) {
        bookReviewMapper.addBookReview(bookReview);
        return 1;
    }

    @Override
    public int updateBookReview(BookReview bookReview) {
        bookReviewMapper.updateBookReview(bookReview);
        return 1;
    }

    @Override
    public int deleteBookReview(int bookreviewid) {
        bookReviewMapper.deleteBookReview(bookreviewid);
        return 1;
    }

    @Override
    public int cnt() {
        return bookReviewMapper.cnt();
    }
}
