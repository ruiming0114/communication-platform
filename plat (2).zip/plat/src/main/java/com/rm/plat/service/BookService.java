package com.rm.plat.service;

import com.rm.plat.pojo.Book;

import java.util.List;

public interface BookService {
    Book queryBookByName(String name);

    List<Book> queryBookList();
    Book queryBookByID(int bookid);

    int addBook(Book book);
    int updateBook(Book book);
    int deleteBook(int bookid);
    int cnt();
}
