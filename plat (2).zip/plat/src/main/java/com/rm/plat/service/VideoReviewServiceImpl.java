package com.rm.plat.service;

import com.rm.plat.mapper.VideoReviewMapper;
import com.rm.plat.pojo.VideoReview;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideoReviewServiceImpl implements VideoReviewService {
    @Autowired
    VideoReviewMapper videoReviewMapper;

    @Override
    public VideoReview queryVideoReviewById(int videoreviewid) {
        return videoReviewMapper.queryVideoReviewById(videoreviewid);
    }

    @Override
    public List<VideoReview> queryVideoReviewListByVideoId(int videoid) {
        return videoReviewMapper.queryVideoReviewListByVideoId(videoid);
    }

    @Override
    public List<VideoReview> queryVideoReviewListByUserId(int userid) {
        return videoReviewMapper.queryVideoReviewListByUserId(userid);
    }

    @Override
    public int addVideoReview(VideoReview videoReview) {
        videoReviewMapper.addVideoReview(videoReview);
        return 1;
    }

    @Override
    public int updateVideoReview(VideoReview videoReview) {
        videoReviewMapper.updateVideoReview(videoReview);
        return 1;
    }

    @Override
    public int deleteVideoReview(int videoreviewid) {
        videoReviewMapper.deleteVideoReview(videoreviewid);
        return 1;
    }

    @Override
    public int cnt() {
        return videoReviewMapper.cnt();
    }
}

