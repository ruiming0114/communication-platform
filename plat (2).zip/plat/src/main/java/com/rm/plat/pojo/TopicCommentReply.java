package com.rm.plat.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TopicCommentReply {

    private int commentreplyid;
    private int commentid;
    private int userid;
    private String content;
    private Time addtime;

    public int getCommentreplyid() {
        return commentreplyid;
    }

    public void setCommentreplyid(int commentreplyid) {
        this.commentreplyid = commentreplyid;
    }

    public int getCommentid() {
        return commentid;
    }

    public void setCommentid(int commentid) {
        this.commentid = commentid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Time getAddtime() {
        return addtime;
    }

    public void setAddtime(Time addtime) {
        this.addtime = addtime;
    }
}
