package com.rm.plat.mapper;

import com.rm.plat.pojo.Video;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface VideoMapper {
    Video queryVideoByName(String name);

    List<Video> queryVideoList();
    Video queryVideoByID(int videoid);

    int addVideo(Video video);
    int updateVideo(Video video);
    int deleteVideo(int videoid);
    int cnt();
}
