package com.rm.plat.service;

import com.rm.plat.mapper.TopicCommentMapper;
import com.rm.plat.pojo.TopicComment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicCommentServiceImpl implements TopicCommentService{

    @Autowired
    TopicCommentMapper topicCommentMapper;

    @Override
    public TopicComment queryTopicCommentById(int commentid) {
        return topicCommentMapper.queryTopicCommentById(commentid);
    }

    @Override
    public List<TopicComment> queryTopicCommentByTopic(int topicid) {
        return topicCommentMapper.queryTopicCommentByTopic(topicid);
    }

    @Override
    public List<TopicComment> queryTopicCommentByUser(int userid) {
        return topicCommentMapper.queryTopicCommentByUser(userid);
    }

    @Override
    public int addTopicComment(TopicComment topicComment) {
        topicCommentMapper.addTopicComment(topicComment);
        return 1;
    }

    @Override
    public int updateTopicComment(TopicComment topicComment) {
        topicCommentMapper.updateTopicComment(topicComment);
        return 1;
    }

    @Override
    public int deleteTopicComment(int commentid) {
        topicCommentMapper.deleteTopicComment(commentid);
        return 1;
    }

    @Override
    public int cnt() {
        return topicCommentMapper.cnt();
    }

    @Override
    public int cntByTopic(int topicid) {
        return topicCommentMapper.cntByTopic(topicid);
    }
}
