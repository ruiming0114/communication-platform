package com.rm.plat.controller;

import com.rm.plat.pojo.Topic;
import com.rm.plat.pojo.TopicComment;
import com.rm.plat.service.TopicCommentService;
import com.rm.plat.service.TopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class TopicController {

    @Autowired
    TopicService topicService;

    @Autowired
    TopicCommentService topicCommentService;

    @RequestMapping("/queryTopicList")
    @ResponseBody
    public List<Topic> queryTopicList(){
        List<Topic> list = topicService.queryTopicList();
        for (Topic topic:list){
            System.out.println(topic);
        }
        return list;
    }

    @RequestMapping("/queryTopicCommentByTopic")
    @ResponseBody
    public List<TopicComment> queryTopicCommentByTopic(){
        List<TopicComment> list = topicCommentService.queryTopicCommentByTopic(1);
        for(TopicComment topicComment:list){
            System.out.println(topicComment);
        }
        return list;
    }

}
