package com.rm.plat.service;

import com.rm.plat.pojo.Video;

import java.util.List;

public interface VideoService {
    Video queryVideoByName(String name);

    List<Video> queryVideoList();
    Video queryVideoByID(int videoid);

    int addVideo(Video video);
    int updateVideo(Video video);
    int deleteVideo(int videoid);
    int cnt();
}
