package com.rm.plat.service;

import com.rm.plat.mapper.VideoScoreMapper;
import com.rm.plat.pojo.VideoScore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VideoScoreServiceImpl implements VideoScoreService {

    @Autowired
    VideoScoreMapper videoScoreMapper;

    @Override
    public float getScoreByUserAndVideo(int userid, int videoid) {
        return videoScoreMapper.getScoreByUserAndVideo(userid,videoid);
    }

    @Override
    public float getAvgScoreByVideo(int videoid) {
        return videoScoreMapper.getAvgScoreByVideo(videoid);
    }

    @Override
    public int addVideoScore(VideoScore videoScore) {
        videoScoreMapper.addVideoScore(videoScore);
        return 1;
    }

    @Override
    public int updateVideoScore(VideoScore videoScore) {
        videoScoreMapper.updateVideoScore(videoScore);
        return 1;
    }

    @Override
    public int deleteVideoScore(int userid, int videoid) {
        videoScoreMapper.deleteVideoScore(userid,videoid);
        return 1;
    }

    @Override
    public int cntByVideo(int videoid) {
        return videoScoreMapper.cntByVideo(videoid);
    }
}
