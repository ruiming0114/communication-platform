package com.rm.plat.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyMvcConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("Index");
        registry.addViewController("/index").setViewName("Index");
        registry.addViewController("/book").setViewName("book/BookIndex");
        registry.addViewController("/bookindex").setViewName("book/BookIndex");
        registry.addViewController("/video").setViewName("video/videoindex");
        registry.addViewController("/videoindex").setViewName("video/videoindex");
        registry.addViewController("/topic").setViewName("topic/topicindex");
        registry.addViewController("/topicindex").setViewName("topic/topicindex");
        registry.addViewController("/group").setViewName("group/groupindex");
        registry.addViewController("/groupindex").setViewName("group/groupindex");
        registry.addViewController("/temp").setViewName("temp/temp");
        registry.addViewController("/personalindex").setViewName("PersonalIndex");
    }
}
