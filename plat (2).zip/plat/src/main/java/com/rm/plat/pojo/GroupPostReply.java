package com.rm.plat.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GroupPostReply {
    private int grouppostreplyid;
    private int grouppostid;
    private int userid;
    private String content;
    private Time addtime;

    public int getGrouppostreplyid() {
        return grouppostreplyid;
    }

    public void setGrouppostreplyid(int grouppostreplyid) {
        this.grouppostreplyid = grouppostreplyid;
    }

    public int getGrouppostid() {
        return grouppostid;
    }

    public void setGrouppostid(int grouppostid) {
        this.grouppostid = grouppostid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Time getAddtime() {
        return addtime;
    }

    public void setAddtime(Time addtime) {
        this.addtime = addtime;
    }
}
