package com.rm.plat.service;

import com.rm.plat.pojo.Topic;

import java.util.List;

public interface TopicService {

    Topic queryTopicById(int topicid);
    Topic queryTopicByTitle(String title);
    List<Topic> queryTopicByClassify(String classify);
    List<Topic> queryTopicByUser(int userid);
    List<Topic> queryTopicList();

    int addTopic(Topic topic);
    int updateTopic(Topic topic);
    int deleteTopic(int topicid);

    int cnt();
}
