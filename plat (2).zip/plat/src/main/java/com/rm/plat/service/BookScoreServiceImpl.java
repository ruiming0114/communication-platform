package com.rm.plat.service;

import com.rm.plat.mapper.BookScoreMapper;
import com.rm.plat.pojo.BookScore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookScoreServiceImpl implements BookScoreService {

    @Autowired
    BookScoreMapper bookScoreMapper;

    @Override
    public float getScoreByUserAndBook(int userid, int bookid) {
        return bookScoreMapper.getScoreByUserAndBook(userid,bookid);
    }

    @Override
    public float getAvgScoreByBook(int bookid) {
        return bookScoreMapper.getAvgScoreByBook(bookid);
    }

    @Override
    public int addBookScore(BookScore bookScore) {
        bookScoreMapper.addBookScore(bookScore);
        return 1;
    }

    @Override
    public int updateBookScore(BookScore bookScore) {
        bookScoreMapper.updateBookScore(bookScore);
        return 1;
    }

    @Override
    public int deleteBookScore(int userid, int bookid) {
        bookScoreMapper.deleteBookScore(userid,bookid);
        return 1;
    }

    @Override
    public int cntByBook(int bookid) {
        return bookScoreMapper.cntByBook(bookid);
    }
}
