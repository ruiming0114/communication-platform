package com.rm.plat.controller;

import com.rm.plat.pojo.Book;
import com.rm.plat.pojo.BookReview;
import com.rm.plat.pojo.BookReviewReport;
import com.rm.plat.service.BookReviewReportService;
import com.rm.plat.service.BookReviewService;
import com.rm.plat.service.BookService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class BookController {

    @Autowired
    BookService bookService;

    @Autowired
    BookReviewService bookReviewService;

    @Autowired
    BookReviewReportService bookReviewReportService;

    @RequestMapping("/book/checkbook")
    public String checkbook(Model model){
        Book book = bookService.queryBookByName("a");
        List<BookReview> list = bookReviewService.queryBookReviewListByBookId(1);
        model.addAttribute("currentbook",book);
        model.addAttribute("bookreview",list);
        return "book/CheckBook";
    }

    @RequestMapping("/queryBookList")
    @ResponseBody
    public List<Book> queryBookList(){
        List<Book> list = bookService.queryBookList();
        for (Book book:list){
            System.out.println(book);
        }
        return list;
    }

    @RequestMapping("/queryBookReviewList")
    @ResponseBody
    public List<BookReview> queryBookReviewList(){
        List<BookReview> list = bookReviewService.queryBookReviewListByUserId(1);

        for (BookReview bookReview:list){
            System.out.println(bookReview);
        }
        return list;
    }

    @RequestMapping("queryBookReviewReportList")
    @ResponseBody
    public List<BookReviewReport> queryBookReviewReportList(){
        List<BookReviewReport> list = bookReviewReportService.queryBookReviewReportList();
        for (BookReviewReport bookReviewReport:list){
            System.out.println(bookReviewReport);
        }
        return list;
    }
}
