package com.rm.plat.service;

import com.rm.plat.pojo.Group;

import java.util.List;

public interface GroupService {
    Group queryGroupById(int groupid);
    Group queryGroupByName(String groupname);
    List<Group> queryGroupList();

    int addGroup(Group group);
    int updateGroup(Group group);
    int deleteGroup(int groupid);

    int cnt();
}
