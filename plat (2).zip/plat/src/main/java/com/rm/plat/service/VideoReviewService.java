package com.rm.plat.service;

import com.rm.plat.pojo.VideoReview;

import java.util.List;

public interface VideoReviewService {
    VideoReview queryVideoReviewById(int videoreviewid);
    List<VideoReview> queryVideoReviewListByVideoId(int videoid);
    List<VideoReview> queryVideoReviewListByUserId(int userid);

    int addVideoReview(VideoReview videoReview);
    int updateVideoReview(VideoReview videoReview);
    int deleteVideoReview(int videoreviewid);
    int cnt();
}
