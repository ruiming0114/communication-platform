package com.rm.plat.service;

import com.rm.plat.mapper.GroupPostMapper;
import com.rm.plat.pojo.GroupPost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupPostServiceImpl implements GroupPostService {

    @Autowired
    GroupPostMapper groupPostMapper;

    @Override
    public GroupPost queryGroupPostById(int grouppostid) {
        return groupPostMapper.queryGroupPostById(grouppostid);
    }

    @Override
    public List<GroupPost> queryGroupPostListByGroup(int groupid) {
        return groupPostMapper.queryGroupPostListByGroup(groupid);
    }

    @Override
    public List<GroupPost> queryGroupPostListByUser(int userid) {
        return groupPostMapper.queryGroupPostListByUser(userid);
    }

    @Override
    public int addGroupPost(GroupPost groupPost) {
        groupPostMapper.addGroupPost(groupPost);
        return 1;
    }

    @Override
    public int updateGroupPost(GroupPost groupPost) {
        groupPostMapper.updateGroupPost(groupPost);
        return 1;
    }

    @Override
    public int deleteGroupPost(int grouppostid) {
        groupPostMapper.deleteGroupPost(grouppostid);
        return 1;
    }

    @Override
    public int cnt() {
        return groupPostMapper.cnt();
    }
}
