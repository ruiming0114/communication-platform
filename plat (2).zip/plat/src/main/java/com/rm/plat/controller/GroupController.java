package com.rm.plat.controller;

import com.rm.plat.pojo.*;
import com.rm.plat.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.ListResourceBundle;

@Controller
public class GroupController {

    @Autowired
    GroupService groupService;

    @Autowired
    GroupMemberService groupMemberService;

    @Autowired
    GroupPostService groupPostService;

    @Autowired
    GroupPostReplyService groupPostReplyService;

    @Autowired
    GroupAdminApplyService groupAdminApplyService;

    @RequestMapping("/queryGroupList")
    @ResponseBody
    public List<Group> queryGroupList(){
        List<Group> list = groupService.queryGroupList();
        for (Group group:list){
            System.out.println(group);
        }
        return list;
    }

    @RequestMapping("/queryGroupMemberList")
    @ResponseBody
    public List<User> queryGroupMemberList(){
        List<User> list = groupMemberService.queryGroupMemberListByGroup(1);
        for (User user:list){
            System.out.println(user);
        }
        return list;
    }

    @RequestMapping("/queryGroupListByUser")
    @ResponseBody
    public List<Group> queryGroupListByUser(){
        List<Group> list = groupMemberService.queryGroupListByUser(1);
        for (Group group:list){
            System.out.println(group);
        }
        return list;
    }

    @RequestMapping("/queryGroupPostListByGroup")
    @ResponseBody
    public List<GroupPost> queryGroupPostListByGroup(){
        List<GroupPost> list = groupPostService.queryGroupPostListByGroup(1);
        for (GroupPost groupPost:list){
            System.out.println(groupPost);
        }
        return list;
    }

    @RequestMapping("/queryGroupPostListByUser")
    @ResponseBody
    public List<GroupPost> queryGroupPostListByUser(){
        List<GroupPost> list = groupPostService.queryGroupPostListByUser(1);
        for (GroupPost groupPost:list){
            System.out.println(groupPost);
        }
        return list;
    }

    @RequestMapping("/queryGroupPostReplyListByGroupPost")
    @ResponseBody
    public List<GroupPostReply> queryGroupPostReplyListByGroupPost(){
        List<GroupPostReply> list = groupPostReplyService.queryGroupPostReplyByGroupPost(1);
        for (GroupPostReply groupPostReply:list){
            System.out.println(groupPostReply);
        }
        return list;
    }

    @RequestMapping("/queryGroupPostReplyListByUser")
    @ResponseBody
    public List<GroupPostReply> queryGroupPostReplyListByUser(){
        List<GroupPostReply> list = groupPostReplyService.queryGroupPostReplyByUser(1);
        for (GroupPostReply groupPostReply:list){
            System.out.println(groupPostReply);
        }
        return list;
    }

    @RequestMapping("/queryGroupAdminApplyListByGroup")
    @ResponseBody
    public  List<GroupAdminApply> queryGroupAdminApplyListByGroup(){
        List<GroupAdminApply> list = groupAdminApplyService.queryGroupAdminApplyByGroup(1);
        for (GroupAdminApply groupAdminApply:list){
            System.out.println(groupAdminApply);
        }
        return list;
    }
}
