package com.rm.plat.service;

import com.rm.plat.pojo.GroupPost;

import java.util.List;

public interface GroupPostService {

    GroupPost queryGroupPostById(int grouppostid);
    List<GroupPost> queryGroupPostListByGroup(int groupid);
    List<GroupPost> queryGroupPostListByUser(int userid);

    int addGroupPost(GroupPost groupPost);
    int updateGroupPost(GroupPost groupPost);
    int deleteGroupPost(int grouppostid);

    int cnt();
}
