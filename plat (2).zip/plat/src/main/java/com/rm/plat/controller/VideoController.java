package com.rm.plat.controller;

import com.rm.plat.pojo.Video;
import com.rm.plat.pojo.VideoReview;
import com.rm.plat.pojo.VideoReviewLiked;
import com.rm.plat.pojo.VideoReviewReport;
import com.rm.plat.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class VideoController {

    @Autowired
    VideoService videoService;

    @Autowired
    VideoScoreService videoScoreService;

    @Autowired
    VideoReviewService videoReviewService;

    @Autowired
    VideoReviewLikedService videoReviewLikedService;

    @Autowired
    VideoReviewReportService videoReviewReportService;

    @RequestMapping("/queryVideoList")
    @ResponseBody
    public List<Video> queryVideoList(){
        List<Video> list = videoService.queryVideoList();
        for (Video video:list){
            System.out.println(video);
        }
        return list;
    }

    @RequestMapping("/queryVideoScore")
    @ResponseBody
    public String queryVideoScore(){
        return String.valueOf(videoScoreService.getAvgScoreByVideo(1));
    }

    @RequestMapping("/queryVideoReview")
    @ResponseBody
    public List<VideoReview> queryVideoReview(){
        List<VideoReview> list = videoReviewService.queryVideoReviewListByVideoId(1);
        for (VideoReview videoReview:list){
            System.out.println(videoReview);
        }
        return list;
    }

    @RequestMapping("/queryVideoReviewLiked")
    @ResponseBody
    public String queryVideoReviewLiked(){
        return String.valueOf(videoReviewLikedService.getLikeStatus(1));
    }

    @RequestMapping("/queryVideoReviewReport")
    @ResponseBody
    public List<VideoReviewReport> queryVideoReviewReport(){
        List<VideoReviewReport> list = videoReviewReportService.queryUndealVideoReviewReportList();
        for (VideoReviewReport videoReviewReport:list){
            System.out.println(videoReviewReport);
        }
        return list;
    }
}
